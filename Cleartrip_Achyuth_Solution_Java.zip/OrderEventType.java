public enum OrderEventType {
    ORDER_PLACED,
    ORDER_SHIPPED,
    ORDER_DELIVERIED;
};
