public interface NotificationChannel {
    void send(String Message);
}
