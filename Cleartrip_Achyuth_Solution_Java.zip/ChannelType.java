public enum ChannelType {
    EMAIL,
    SMS,
    PUSH;
};
